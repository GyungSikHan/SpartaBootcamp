#pragma once
#include <iostream>
#include <algorithm>
using namespace std;

template<typename T>
class SimpleVector
{
public:
	SimpleVector()
	{
		m_pVector = new T[10]{};
		m_nCurrentSize = 0;
		m_nCurrentCapacity = 10;
	}
	SimpleVector(int nCapacity)
	{
		m_pVector = new T[nCapacity];
		m_nCurrentSize = 0;
		m_nCurrentCapacity = nCapacity;
	}
	SimpleVector(const SimpleVector& other)
	{
		m_nCurrentSize = 0;
		m_nCurrentCapacity = other.Capacity();
		m_pVector = new T[m_nCurrentCapacity];
		for (int i = 0; i < other.Size(); i++)
		{
			Push_Back(other.GetData()[i]);
		}
	}
	~SimpleVector()
	{
		delete[] m_pVector;
		m_pVector = nullptr;
	}
	void Push_Back(const T& data)
	{
		if(m_nCurrentCapacity <= m_nCurrentSize)
			Resize(5);

		m_pVector[m_nCurrentSize] = data;
		m_nCurrentSize++;
	}

	void Pop_Back()
	{
		if(m_nCurrentSize <= 0)
		{
			cout << "�������" << endl;
			return;
		}
		T temp{};
		m_pVector[m_nCurrentSize] = temp;
		m_nCurrentSize--;
	}

	int Size() const
	{
		return m_nCurrentSize;
	}

	int Capacity() const
	{
		return m_nCurrentCapacity;
	}

	void Resize(int newCapacity)
	{
		int tempCapacity = m_nCurrentCapacity + newCapacity;
		T* temp = new T[tempCapacity];
		for (int i = 0; i < m_nCurrentCapacity; i++)
			temp[i] = m_pVector[i];
		m_nCurrentCapacity = tempCapacity;
		delete m_pVector;
		m_pVector = temp;
	}

	void PrintAllData()
	{
		for (int i = 0; i < m_nCurrentSize; i++)
		{
			cout << m_pVector[i] << endl;
		}
	}

	void PrintIndexData(int index)
	{
		if(index >= m_nCurrentSize)
		{
			cout << "������ index�� �ʰ���" << endl;
			return;
		}
		cout << m_pVector[index] << endl;
	}

	T* GetData() const
	{
		return m_pVector;
	}

	void Sort()
	{
		sort(m_pVector, m_pVector + m_nCurrentSize);
	}
private:
	T* m_pVector;
	int m_nCurrentSize;
	int m_nCurrentCapacity;
};