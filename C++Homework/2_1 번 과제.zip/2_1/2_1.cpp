﻿#include <iostream>
#include "SimpleVector.h"

using namespace std;

int main()
{
	SimpleVector<int> v{};
	cout << "size : " << v.Size() << " capacity : " << v.Capacity() << endl;
	for (int i = 0; i < 10; i++)
		v.Push_Back(i);
	v.Push_Back(3);
	v.PrintIndexData(4);
	v.PrintAllData();
	cout << "size : " << v.Size() << " capacity : " << v.Capacity() << endl;

	SimpleVector<char> v2(7);
	cout << "size : " << v2.Size() << " capacity : " << v2.Capacity() << endl;
	for (int i = 0; i < 7; i++)
		v2.Push_Back('a' + i);

	v2.PrintIndexData(4);
	v2.PrintAllData();
	cout << "size : " << v2.Size() << " capacity : " << v2.Capacity() << endl;
	v2.Push_Back('h');
	v2.PrintAllData();
	cout << "size : " << v2.Size() << " capacity : " << v2.Capacity() << endl;

	SimpleVector<int> v3(v);
	v3.PrintAllData();
	v3.Pop_Back();
	v3.Pop_Back();
	v3.Pop_Back();
	v3.Pop_Back();
	v3.PrintAllData();

	SimpleVector<int> v4{};
	v4.Push_Back(3);
	v4.Push_Back(2);
	v4.Push_Back(1);
	v4.Push_Back(4);
	v4.Push_Back(5);
	v4.Push_Back(8);
	v4.Push_Back(6);
	v4.Push_Back(7);
	v4.Push_Back(9);
	v4.Push_Back(0);
	v4.Sort();
	v4.PrintAllData();
}