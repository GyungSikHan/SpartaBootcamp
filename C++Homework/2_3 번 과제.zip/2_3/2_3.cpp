﻿// 2_3.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include <iostream>
#include <vector>
using namespace std;

int main()
{
	string s;
	cin >> s;
	vector<string>v(s.size(),"");

	for (int i = 0; i < (int)s.size(); i++)
	{
		v[i] += s[i];
		for (int j = 0; j < (int)s.size(); j++)
		{
			if (i != j)
				v[i] += s[j];
		}
	}

	for (string temp : v)
	{
		cout << temp << endl;
	}
}