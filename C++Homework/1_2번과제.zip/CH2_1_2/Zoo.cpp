#include "Zoo.h"
#include <cmath>
Zoo::Zoo()
{
	srand(time(nullptr));
}

Zoo::~Zoo()
{
	for (int i = 0; i < 10; i++)
	{
		if(animals[i] != nullptr)
		{
			delete animals[i];
			animals[i] = nullptr;
		}
	}
}

void Zoo::AddAnimal(Animal* ather)
{
	if (length > 10)
	{
		cout << "�������� ���� á���ϴ�!!" << endl;
		return;
	}
	animals[length - 1] = ather;
	length++;
}

void Zoo::PerformActions()
{
	for (int i = 0; i < 10; i++)
		animals[i]->MakeSound();
}

Animal* Zoo::CreateRandomAnimal()
{
	
	int data = rand() % 3 - 1;

	if(data == 0)
	{
		cout << "�� ����" << endl;
		return new Dog();
	}
	else if(data == 1)
	{
		cout << "������ ����" << endl;
		return new Cat();
	}

	cout << "�� ����" << endl;
	return new Cow();
}
