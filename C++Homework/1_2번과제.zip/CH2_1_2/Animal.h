#pragma once
#include <iostream>
using namespace std;

class Animal
{
public:
	Animal() {}
	virtual ~Animal() {}
	virtual void MakeSound() = 0;
};

class Dog : public Animal
{
public:
	Dog() {}
	~Dog() {}
	virtual void MakeSound() override;
};

class Cat : public Animal
{
public:
	Cat() {}
	~Cat() {}
	virtual void MakeSound() override;
};

class Cow : public Animal
{
public:
	Cow() {}
	~Cow() {}
	virtual void MakeSound() override;
};
