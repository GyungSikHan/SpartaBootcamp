#pragma once
#include "Animal.h"

class Zoo
{
private:
	Animal* animals[10];
	int length = 1;
public:
	Zoo();
	~Zoo();
	void AddAnimal(Animal* ather);
	void PerformActions();
	Animal* CreateRandomAnimal();
};

