#include "Animal.h"

void Dog::MakeSound()
{
	cout << "��" << endl;
}

void Cat::MakeSound()
{
	cout << "�߿�" << endl;
}

void Cow::MakeSound()
{
	cout << "����" << endl;
}
