#pragma once
#include<unordered_map>
#include <string>
#include "Book.h"
using namespace std;

class BorrowMGR
{
public:
	BorrowMGR();
	void InitializeStock(Book book, int quantity = 3);
	void BorrowBook(string title);
	void ReturnBook(string title);
	void Display();
private:
	unordered_map<string, int> stockTitle;
	unordered_map<string, int> stockAuthor;
	unordered_map<string, int> temp;
};

