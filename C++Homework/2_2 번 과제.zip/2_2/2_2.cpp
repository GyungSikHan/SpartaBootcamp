﻿#include <iostream>
#include <vector>
#include <string>
#include "BookMGR.h"
#include "BorrowMGR.h"

using namespace std;

int main()
{
	BookManager manager;
	BorrowMGR borrowMGR;
	while (true) 
	{
		cout << "\n도서관 관리 프로그램" << endl;
		cout << "1. 책 추가" << endl;
		cout << "2. 모든 책 출력" << endl;
		cout << "3. 책 재고 출력" << endl;
		cout << "4. 책 제목으로 검색해 빌리기" << endl;
		cout << "5. 저자로 검색해 빌리기" << endl;
		cout << "6. 책 반납" << endl;
		cout << "7. 종료" << endl;
		cout << "선택: ";

		int choice;
		string search{};
		cin >> choice;

		if (choice == 1)
		{
			string title, author;
			int quantity{};
			cout << "책 제목 : ";
			cin.ignore();
			getline(cin, title);
			cout << "책 저자: ";
			getline(cin, author);
			cout << "등록할 권수 : ";
			cin >> quantity;
			manager.addBook(title, author);
			borrowMGR.InitializeStock((*manager.GetBookByTitle(title)),quantity);
		}
		else if (choice == 2)
			manager.displayAllBooks();
		else if (choice == 3)
			borrowMGR.Display();
		else if (choice == 4)
		{
			cout << "책 이름 : ";
			cin >> search;
			if (manager.GetBookByTitle(search) != nullptr)
			{
				cout << search << "책을 대여합니다" << endl;
				borrowMGR.BorrowBook(manager.GetBookByTitle(search)->GetTitle());
			}
			else
				cout << "그런 책은 없습니다" << endl;
		}
		else if (choice == 5)
		{
			cout << "저자 이름 : ";
			cin >> search;
			if (manager.GetBookByAuthor(search) != nullptr)
			{
				Book temp = *manager.GetBookByAuthor(search);
				cout << search << " 작가의 책" << temp.GetTitle() << "을 빌립니다" << endl;
				borrowMGR.BorrowBook(temp.GetTitle());
			}
			else
				cout << "그런 작가의 책은 없습니다" << endl;
		}
		else if(choice == 6)
		{
			cout << "반납할 책을 입력하세요" << endl;
			manager.displayAllBooks();
			cin >> search;
			borrowMGR.ReturnBook(manager.GetBookByTitle(search)->GetTitle());
		}
		else if (choice == 7)
			cout << "프로그램을 종료합니다." << endl;
		else
			cout << "잘못된 입력입니다. 다시 시도하세요." << endl;
	}
}