#pragma once
#include <string>
using namespace std;

class Book
{
private:
	std::string title;
    string author;
public:
    Book(const string& title, const string& author);
	string GetTitle() const;
	string GetAuthor() const;
};

