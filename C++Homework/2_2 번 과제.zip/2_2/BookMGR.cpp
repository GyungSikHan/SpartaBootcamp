#include <iostream>
#include "BookMGR.h"
#include "Book.h"

BookManager::BookManager()
{
}

void BookManager::addBook(const string& title, const string& author)
{
	books.push_back(Book(title, author)); // push_back ���
	cout << "å�� �߰��Ǿ����ϴ�: " << title << " by " << author << endl;
}

void BookManager::displayAllBooks() const
{
	if (books.empty()) {
		cout << "���� ��ϵ� å�� �����ϴ�." << endl;
		return;
	}

	cout << "���� ���� ���:" << endl;
	for (size_t i = 0; i < books.size(); i++)
	{ // �Ϲ����� for�� ���
		cout << "- " << books[i].GetTitle() << " by " << books[i].GetAuthor() << endl;
	}
}

//void BookManager::searchByTitle(string title)
//{
//	bool bSearch{};
//	for (auto a : books)
//	{
//		if (a.GetTitle() == title)
//		{
//			cout << a.GetTitle() << " by " << a.GetAuthor() << endl;
//			bSearch = true;
//			break;
//		}
//	}
//	if (bSearch == false)
//		cout << "å�� �����ϴ�" << endl;
//}
//
//void BookManager::searchByAuthor(string author)
//{
//	for (Book book : books)
//	{
//		if (book.GetAuthor() == author)
//			cout << book.GetTitle() << " by " << book.GetAuthor() << endl;
//	}
//}


Book* BookManager::GetBookByTitle(string title)
{
	return FindBookByTitle(title);
}

Book* BookManager::GetBookByAuthor(string author)
{
	return FindBookByAuthor(author);
}

Book* BookManager::FindBookByTitle(string title)
{
	for (int i = 0; i < books.size(); i++)
	{
		if (title == books[i].GetTitle())
			return &books[i];
	}
	return nullptr;
}

Book* BookManager::FindBookByAuthor(string author)
{
	for (int i = 0; i < books.size(); i++)
	{
		if (author == books[i].GetAuthor())
			return &books[i];
	}
	return nullptr;
}
