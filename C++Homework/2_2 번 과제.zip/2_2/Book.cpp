#include "Book.h"
Book::Book(const string& title, const string& author)
    : title(title), author(author)
{
}

string Book::GetTitle() const
{
    return title;
}

string Book::GetAuthor() const
{
    return author;
}
