# pragma once
#include <string>
#include <vector>
#include "Book.h"

using namespace std;

class BookManager
{
private:
    vector<Book> books;

public:
    BookManager();
    void addBook(const string& title, const string& author);
    void displayAllBooks() const;
    //void searchByTitle(string title);
    //void searchByAuthor(string author);

    Book* GetBookByTitle(string title);
    Book* GetBookByAuthor(string author);
private:
    Book* FindBookByTitle(string title);
    Book* FindBookByAuthor(string author);
};